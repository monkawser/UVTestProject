﻿namespace TestProjectForUV.Model
{
    public class BkashSettings
    {
        public string ApiKey { get; set; }
        public string BaseUrl { get; set; }
        public string DefaultAmount { get; set; }
    }
}
