﻿using Microsoft.AspNetCore.Mvc;

namespace TestProjectForUV.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class GenerateRandomStringController : ControllerBase
    {
        [HttpGet, Route("GenerateRandomValue")]       
        public IActionResult GenerateRandomStringValue()
        {
            string reandomString =  Guid.NewGuid().ToString();
            return Ok(reandomString);
        }
    }
}
