﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using TestProjectForUV.Model;

namespace TestProjectForUV.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class GenerateJsonController : ControllerBase
    {
        [HttpGet, Route("GenerateJsonString")]
        public IActionResult GenerateJsonString()
        {
            var randomJson = new SubscriptionData()
            {
                amount = new Random().Next(1, 1000).ToString(),
                firstPaymentIncludedInCycle = "True",
                serviceId = "100001",
                currency = "BDT",
                startDate = DateTime.Now.ToString(),
                expiryDate = DateTime.Now.AddMonths(1).ToString(),
                frequency = "MONTHLY",
                subscriptionType = "BASIC",
                maxCapRequired = "False",
                merchantShortCode = "01307153119",
                payerType = "CUSTOMER",
                paymentType = "FIXED",
                redirectUrl = "http://localhost:5262/",
                subscriptionRequestId = Guid.NewGuid().ToString(),
                subscriptionReference = "01918395578",
                ckey = "000001"

            };
            var jsonString = JsonConvert.SerializeObject(randomJson);
            return Ok(jsonString);
        }
    }
}
