﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System.Text;
using TestProjectForUV.Model;

namespace TestProjectForUV.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PaymentGetwayController : Controller
    {
        private readonly BkashSettings _bkashSettings;

        public PaymentGetwayController(IOptions<BkashSettings> bkashSettings)
        {
            _bkashSettings = bkashSettings.Value;
        }

        [HttpPost, Route("PaymentToBkash")]
        public async Task<IActionResult> PaymentToBkash(string subscriptionType)
        {

            var subscription = new SubscriptionData
            {
                amount = _bkashSettings.DefaultAmount,
                firstPaymentIncludedInCycle = "True",
                serviceId = "100001",
                currency = "BDT",
                startDate = DateTime.Now.ToString(),
                expiryDate = DateTime.Now.AddMonths(1).ToString(),
                frequency = "MONTHLY",
                subscriptionType = "BASIC",
                maxCapRequired = "False",
                merchantShortCode = "01307153119",
                payerType = "CUSTOMER",
                paymentType = "FIXED",
                redirectUrl = "http://localhost:5262/",
                subscriptionRequestId = Guid.NewGuid().ToString(),
                subscriptionReference = "01918395578",
                ckey = "000001"
            };
            if (!string.IsNullOrEmpty(subscriptionType) && subscriptionType.ToUpper() == "MONTHLY")
            {
                subscription.frequency = subscriptionType.ToUpper();
                subscription.expiryDate = DateTime.Now.AddDays(30).ToString();
            }
            else if (!string.IsNullOrEmpty(subscriptionType) && subscriptionType.ToUpper() == "WEEKLY")
            {
                subscription.frequency = subscriptionType.ToUpper();
                subscription.expiryDate = DateTime.Now.AddDays(7).ToString();
            }
            else if (!string.IsNullOrEmpty(subscriptionType) && subscriptionType.ToUpper() == "DAILY")
            {
                subscription.frequency = subscriptionType.ToUpper();
                subscription.expiryDate = DateTime.Now.AddDays(1).ToString();
            }

            using var client = new HttpClient();
            client.DefaultRequestHeaders.Add("api-key", _bkashSettings.ApiKey);
            var jsonData = JsonConvert.SerializeObject(subscription);
            var content = new StringContent(jsonData, Encoding.UTF8, "application/json");
            var response = await client.PostAsync(_bkashSettings.BaseUrl, content);



            if (response.IsSuccessStatusCode)
            {
                var responseBody = await response.Content.ReadAsStringAsync();

                var result = new
                {
                    requestData = jsonData,
                    responseBody = responseBody
                };
                return Ok(result);
            }

            return StatusCode((int)response.StatusCode, "Error posting to bKash API");
        }
    }
}
